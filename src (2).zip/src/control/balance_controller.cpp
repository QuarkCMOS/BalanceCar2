#include "balance_controller.h"
#include <math.h>

BalanceController::BalanceController(MotorDriver&          leftMotor,
                                     MotorDriver&          rightMotor,
                                     MPU6050Manager&       imu,
                                     ComplementaryFilter&  filter,
                                     EncoderManager&       encLeft,
                                     EncoderManager&       encRight)
    : _leftMotor(leftMotor)
    , _rightMotor(rightMotor)
    , _imu(imu)
    , _filter(filter)
    , _encLeft(encLeft)
    , _encRight(encRight)
{}

bool BalanceController::begin() {
    _pid.setTunings(PID_KP, PID_KI, PID_KD);
    _pid.setOutputLimits(-PID_OUTPUT_MAX, PID_OUTPUT_MAX);
    _pid.setIntegralLimits(-PID_INTEGRAL_MAX, PID_INTEGRAL_MAX);
    _pid.reset();

    _velPID.setTunings(VEL_PID_KP, VEL_PID_KI, VEL_PID_KD);
    _velPID.setOutputLimits(-VEL_PID_OUTPUT_MAX, VEL_PID_OUTPUT_MAX);
    _velPID.setIntegralLimits(-VEL_PID_INTEGRAL_MAX, VEL_PID_INTEGRAL_MAX);
    _velPID.reset();

    _posPID.setTunings(POS_PID_KP, POS_PID_KI, POS_PID_KD);
    _posPID.setOutputLimits(-POS_PID_OUTPUT_MAX, POS_PID_OUTPUT_MAX);
    _posPID.setIntegralLimits(-POS_PID_INTEGRAL_MAX, POS_PID_INTEGRAL_MAX);
    _posPID.reset();

    _state = BalanceState::IDLE;
    return true;
}

void BalanceController::update(float dt) {
    // ── 1. Đọc IMU ──────────────────────────────────────────
    _imu.update();
    IMUData d = _imu.getData();

    // ── 2. Tính góc acc theo axisMode ───────────────────────
    float a1 = d.accY;
    float a2 = -d.accZ;
    float gyroRate = -d.gyroX;

    _accAngle = atan2f(a1, a2) * (180.0f / PI);
    float filteredAngle = _filter.update(_accAngle, gyroRate, dt);
    _currentAngle = filteredAngle;

    // ── 3. IDLE / ERROR → brake cứng ────────────────────────
    if (_state == BalanceState::IDLE || _state == BalanceState::ERROR) {
        _leftMotor.hardBrake();
        _rightMotor.hardBrake();
        return;
    }

    // ── 4. FIX: xử lý FALLEN trước khi check góc ────────────
    if (_state == BalanceState::FALLEN) {
        _leftMotor.hardBrake();
        _rightMotor.hardBrake();

        // Xe được dựng lại: góc về gần 0 → auto-recover
        if (filteredAngle < FALL_ANGLE * 0.5f &&
            filteredAngle > -FALL_ANGLE * 0.5f) {
            _pid.reset();
            _state = BalanceState::RUNNING;
        }
        return;
    }

    // ── 5. Phát hiện ngã (chỉ khi đang RUNNING) ─────────────
    if (filteredAngle > FALL_ANGLE || filteredAngle < -FALL_ANGLE) {
        handleFall();
        return;
    }

    // ── 6. RUNNING: Cascade PID → motor ─────────────────────
    // Tầng ngoài: Position PID → targetVelocity, Velocity PID → angle offset
    _velOffset = runCascadeOuterLoops(dt);
    // Tầng trong: Angle PID → PWM
    _pidOutput = _pid.compute(_targetAngle + _velOffset, filteredAngle, dt);
    applyMotorCommand(_pidOutput);
}

void BalanceController::setAxisMode(uint8_t mode) {
    if (mode > 5) return;
    _axisMode = mode;

    // FIX: reset filter về góc thực tế, không phải 0
    float realAngle = _imu.readAccAngleOnce();
    _filter.reset(realAngle);
}

void BalanceController::setTargetAngle(float angle) {
    _targetAngle = angle;
}

void BalanceController::setDifferentialPWM(float delta) {
    _diffDelta = delta;
}

// FIX: cho phép enable từ cả IDLE lẫn FALLEN
// FIX: reset filter về góc acc thực tế trước khi chạy PID
void BalanceController::enable() {
    if (_state == BalanceState::IDLE || _state == BalanceState::FALLEN) {
        // Đọc góc thực tế và init filter từ đó → tránh PID spike lần đầu
        float realAngle = _imu.readAccAngleOnce();
        _filter.reset(realAngle);
        _pid.reset();
        _velPID.reset();
        _posPID.reset();
        _velocityIntegral = 0.0f;
        _velocity = 0.0f;
        _state = BalanceState::RUNNING;
    }
}

void BalanceController::disable() {
    _leftMotor.hardBrake();
    _rightMotor.hardBrake();
    _leftPWM  = 0;
    _rightPWM = 0;
    _pid.reset();
    _velPID.reset();
    _posPID.reset();
    _state = BalanceState::IDLE;
    _diffDelta = 0.0f;
    _velocityIntegral = 0.0f;
    _velocity = 0.0f;
    _velOffset = 0.0f;
}

void BalanceController::setPIDTunings(float kp, float ki, float kd) {
    _pid.setTunings(kp, ki, kd);
}

void BalanceController::setVelPIDTunings(float kp, float ki, float kd) {
    _velPID.setTunings(kp, ki, kd);
}

void BalanceController::setTargetVelocity(float v) {
    _targetVelocity = v;
}

void BalanceController::setPosPIDTunings(float kp, float ki, float kd) {
    _posPID.setTunings(kp, ki, kd);
}

void BalanceController::setTargetPosition(float pos) {
    _targetPosition = pos;
}

void BalanceController::setCascadePositionEnabled(bool enabled) {
    _cascadePosEnabled = enabled;
    if (!enabled) {
        _posPID.reset();
    }
}

void BalanceController::handleFall() {
    _leftMotor.hardBrake();
    _rightMotor.hardBrake();
    _leftPWM   = 0;
    _rightPWM  = 0;
    _pidOutput = 0.0f;
    _velOffset = 0.0f;
    _pid.reset();
    _velPID.reset();
    _posPID.reset();
    _velocityIntegral = 0.0f;
    _velocity = 0.0f;
    _state = BalanceState::FALLEN;
}

// ================================================================
// Cascade outer loops: Position PID → targetVelocity, Velocity PID → angle offset
//
//   _posPID:  error = targetPosition - position(_velocityIntegral)
//             output = targetVelocity   (m/s)
//   _velPID:  error = targetVelocity - velocity (encoder, m/s)
//             output = angle offset (độ) — cộng vào _targetAngle trước
//                       khi đưa vào Angle PID
//
// Nếu _cascadePosEnabled == false → bỏ qua Position PID, dùng
// _targetVelocity do người dùng/web set trực tiếp (mặc định 0).
// ================================================================
float BalanceController::runCascadeOuterLoops(float dt) {
    // Vận tốc trung bình 2 bánh (m/s)
    EncoderData el = _encLeft.getData();
    EncoderData er = _encRight.getData();
    _velocity = (el.velocityMs + er.velocityMs) * 0.5f;

    // Tích phân vận tốc → ước tính vị trí tương đối (m)
    _velocityIntegral += _velocity * dt;
    constexpr float POS_INTEGRAL_MAX = 2.0f;  // ±2 m clamp vị trí ước tính
    if (_velocityIntegral >  POS_INTEGRAL_MAX) _velocityIntegral =  POS_INTEGRAL_MAX;
    if (_velocityIntegral < -POS_INTEGRAL_MAX) _velocityIntegral = -POS_INTEGRAL_MAX;

    // ── Tầng Position: error = targetPosition - position ──────
    float velSetpoint = _targetVelocity;
    if (_cascadePosEnabled) {
        velSetpoint = _posPID.compute(_targetPosition, _velocityIntegral, dt);
    }

    // ── Tầng Velocity: error = velSetpoint - velocity ──────────
    float angleOffset = _velPID.compute(velSetpoint, _velocity, dt);

    return angleOffset;
}

void BalanceController::applyMotorCommand(float command) {
    int pwm = static_cast<int>(command);
    if (pwm >  PWM_MAX) pwm =  PWM_MAX;
    if (pwm < -PWM_MAX) pwm = -PWM_MAX;

    // Apply differential steering
    int deltaInt = static_cast<int>(_diffDelta);
    if (deltaInt >  PWM_MAX) deltaInt =  PWM_MAX;
    if (deltaInt < -PWM_MAX) deltaInt = -PWM_MAX;

    int leftSpd = pwm - deltaInt;
    int rightSpd = pwm + deltaInt;

    // Clamp to PWM range
    if (leftSpd >  PWM_MAX) leftSpd =  PWM_MAX;
    if (leftSpd < -PWM_MAX) leftSpd = -PWM_MAX;
    if (rightSpd >  PWM_MAX) rightSpd =  PWM_MAX;
    if (rightSpd < -PWM_MAX) rightSpd = -PWM_MAX;

    _leftPWM  = leftSpd;
    _rightPWM = rightSpd;

    _leftMotor.setSpeed(_leftPWM);
    _rightMotor.setSpeed(_rightPWM);
}